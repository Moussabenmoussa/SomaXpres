# 🚀 Crypto Signals Bot

بوت توصيات تداول العملات الرقمية الاحترافي

![Python](https://img.shields.io/badge/Python-3.11-blue)
![Flask](https://img.shields.io/badge/Flask-3.0-green)
![MongoDB](https://img.shields.io/badge/MongoDB-Atlas-green)
![Telegram](https://img.shields.io/badge/Telegram-Bot-blue)

## ✨ المميزات

- 📊 **تحليل فني متقدم**: RSI, MACD, EMA, Bollinger Bands, Volume Analysis
- 🔄 **بيانات حية**: اتصال مباشر بـ Binance API (Spot & Futures)
- 📱 **إرسال تيليجرام**: توصيات تلقائية لقناتك
- 💾 **قاعدة بيانات**: MongoDB Atlas لحفظ السجلات
- 🌐 **لوحة تحكم**: واجهة ويب احترافية
- ⏰ **يعمل 24/7**: على Render.com مجاناً

## 🏗️ البنية

```
crypto-signals-bot/
├── app.py                    # السيرفر الرئيسي
├── requirements.txt          # المكتبات
├── Procfile                  # إعدادات Render
├── render.yaml               # تكوين Render
├── .env.example              # متغيرات البيئة
├── services/
│   ├── binance_service.py    # جلب بيانات Binance
│   ├── analyzer.py           # التحليل الفني
│   ├── telegram_service.py   # إرسال التوصيات
│   └── database.py           # عمليات MongoDB
└── templates/
    └── index.html            # لوحة التحكم
```

## 🚀 التثبيت والنشر

### 1. إنشاء الحسابات

#### Telegram Bot
1. افتح [@BotFather](https://t.me/BotFather)
2. أرسل `/newbot`
3. اختر اسم للبوت
4. احفظ **Token** الذي ستحصل عليه

#### Chat ID
1. أنشئ قناة أو مجموعة
2. أضف البوت كـ Admin
3. أرسل رسالة في القناة
4. افتح: `https://api.telegram.org/bot<TOKEN>/getUpdates`
5. ابحث عن `"chat":{"id": YOUR_CHAT_ID}`

#### MongoDB Atlas
1. اذهب إلى [MongoDB Atlas](https://cloud.mongodb.com)
2. أنشئ حساب مجاني
3. أنشئ Cluster جديد (اختر Free Tier)
4. أنشئ Database User
5. اضغط "Connect" واختر "Connect your application"
6. انسخ Connection String

### 2. رفع الكود على GitHub

```bash
# انسخ المشروع
git clone https://github.com/YOUR_USERNAME/crypto-signals-bot.git
cd crypto-signals-bot

# أو ابدأ من الصفر
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/crypto-signals-bot.git
git push -u origin main
```

### 3. النشر على Render

1. اذهب إلى [Render.com](https://render.com)
2. اضغط "New" → "Web Service"
3. اربط حساب GitHub
4. اختر الـ Repository
5. الإعدادات:
   - **Name**: crypto-signals-bot
   - **Environment**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`
6. أضف Environment Variables:
   - `TELEGRAM_BOT_TOKEN`: توكن البوت
   - `TELEGRAM_CHAT_ID`: ID القناة
   - `MONGODB_URI`: رابط MongoDB
7. اضغط "Create Web Service"

### 4. إعداد MongoDB Network Access

1. في MongoDB Atlas، اذهب إلى "Network Access"
2. اضغط "Add IP Address"
3. اختر "Allow Access from Anywhere" (0.0.0.0/0)
4. اضغط "Confirm"

## 📊 كيف يعمل البوت

```
كل 5 دقائق:
    │
    ├── جلب Top 50 عملة من Binance
    │
    ├── لكل عملة:
    │   ├── جلب بيانات OHLCV
    │   ├── حساب المؤشرات الفنية
    │   │   ├── RSI (14)
    │   │   ├── MACD (12, 26, 9)
    │   │   ├── EMA (9, 21, 50, 200)
    │   │   ├── Bollinger Bands (20, 2)
    │   │   └── Volume Analysis
    │   │
    │   ├── حساب قوة الإشارة (0-100%)
    │   │
    │   └── إذا قوة > 70%:
    │       ├── حفظ في MongoDB
    │       └── إرسال لتيليجرام
    │
    └── تحديث لوحة التحكم
```

## 🔧 التخصيص

### تغيير إعدادات المسح

في `services/database.py`:

```python
def _default_settings(self) -> Dict:
    return {
        'scan_interval': 5,          # دقائق
        'min_signal_strength': 70,   # الحد الأدنى
        'timeframes': ['5m', '15m', '1h', '4h'],
        'markets': ['spot', 'futures'],
        'top_coins_count': 50
    }
```

### تعديل حساب قوة الإشارة

في `services/analyzer.py`:

```python
def calculate_signal_strength(self, indicators: Dict) -> int:
    # عدّل الأوزان حسب استراتيجيتك
    score = 50
    # RSI: -15 إلى +15
    # MACD: -15 إلى +15
    # EMA: -15 إلى +15
    # ...
```

## 📱 شكل الرسالة في تيليجرام

```
🟢 إشارة شراء قوية 💪💪

━━━━━━━━━━━━━━━━━━━━

💎 العملة: BTCUSDT
📊 الإطار: 1h
🏦 السوق: FUTURES
⏰ الوقت: 2025-01-04 15:30 UTC

━━━━━━━━━━━━━━━━━━━━

💰 الدخول: $97,250.0000
🛑 وقف الخسارة: $96,800.0000 (-0.46%)

✅ الهدف 1: $97,800.0000 (+0.56%)
✅ الهدف 2: $98,200.0000 (+0.97%)
✅ الهدف 3: $98,800.0000 (+1.59%)

━━━━━━━━━━━━━━━━━━━━

📈 Risk/Reward: 1:2.1
💪 قوة الإشارة: 85%

━━━━━━━━━━━━━━━━━━━━

📊 المؤشرات الفنية:

• RSI: 42.0 ⬇️ تشبع بيعي
• MACD: ✅ تقاطع صاعد
• EMA: 📈 صاعد قوي
• Volume: 🔥 مرتفع جداً (2.5x)

━━━━━━━━━━━━━━━━━━━━

⚠️ تنبيه: هذه توصية للتحليل فقط وليست نصيحة مالية.

🤖 Crypto Signals Bot
```

## 🔗 API Endpoints

| Endpoint | Method | الوصف |
|----------|--------|-------|
| `/` | GET | لوحة التحكم |
| `/api/status` | GET | حالة البوت |
| `/api/signals` | GET | آخر الإشارات |
| `/api/signals/history` | GET | سجل الإشارات |
| `/api/top-coins` | GET | أفضل 50 عملة |
| `/api/analyze/<symbol>` | GET | تحليل عملة محددة |
| `/api/settings` | GET/POST | إعدادات البوت |

## ⚠️ تنبيه مهم

> هذا البوت للأغراض التعليمية والتحليلية فقط.
> التداول يحمل مخاطر عالية وقد تخسر كامل رأس مالك.
> لا تتداول بأموال لا تستطيع تحمل خسارتها.

## 📄 الرخصة

MIT License

## 🤝 المساهمة

المساهمات مرحب بها! افتح Issue أو Pull Request.

---

صنع بـ ❤️ للمتداولين العرب
